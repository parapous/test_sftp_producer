#!/bin/sh

set -o errexit
set -o nounset

java ${JAVA_OPTS:-} -Dlog4j.configurationFile=/workingdir/log4j2.xml \
-jar /workingdir/service.jar
#-javaagent:/jmx/jmx_prometheus_javaagent-0.12.0.jar=80:/jmx/producer.yml \

#tail -f /etc/hosts