/*
 * Filename : CustomProducerVariables.java
 * Description : Contains all static variables for the custom producer.
 */

package com.projet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import com.gozen.AdditionalColumn;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static java.lang.Long.valueOf;

public class CustomProducerVariables {
    // Bootstrap Servers, if you want multiple, separate them with ","
    public String BootstrapServers = System.getenv("bootstrap-servers");

    // Topic name
    public String TopicName = System.getenv("topic");

    // Producer username
    public String ProducerUsername = System.getenv("producer-username");

    // Producer password
    public String ProducerPassword = System.getenv("producer-password");

    // Number of partitions
    public String NumberOfPartitions = System.getenv("number-partitions");

    // Replication factor
    public String ReplicationFactor = System.getenv("replication-factor");

    // Key serializer class
    public String KeySerializerClass = "org.apache.kafka.common.serialization.StringSerializer";

    // Value serializer class
    public String ValueSerializerClass = "org.apache.kafka.common.serialization.StringSerializer";

    // SASL Mechanism
    public String SaslMechanism = System.getenv("sasl-mechanism");

    // Security protocol
    public String SecurityProtocol = System.getenv("security-protocol");

    // SSL Certificate location
    public String SslCaLocation = System.getenv("ssl-ca-location");

    // Message backoff, delay between each message, initialized by default at 100ms, but imported from env variables at checkup
    public Long MessageBackOff = valueOf(100);

    // Retry delay in Seconds
    public Long retryDelay = valueOf(60);

    // SFTP Username
    public String SftpUsername = System.getenv("sftp-username");

    // SFTP private Key
    public String SftpPrivateKey = new String(Files.readAllBytes(Paths.get(getClass().getResource("gozenadmin_private_key.ppk").toString())));

    // SFTP Host
    public String SftpHost = System.getenv("sftp-host");

    // SFTP Port
    public int SftpPort = 22;

    // SFTP Path
    public String SftpPath = System.getenv("sftp-path");

    // SFTP Check delay
    public int SftpCheckDelay = 10000;

    // File char encoding
    public String FileEncoding = System.getenv("file-encoding");

    // CSV First row as header
    public String FirstRowAsHeader = System.getenv("first-row-as-header");

    // CSV Column Separator
    public String Separator = System.getenv("csv-separator");

    // Additional columns array
    public AdditionalColumn[] AdditionalColumns = null;

    // GSON object, allows to serialize/Deserialize JSON data
    private Gson _gson = new GsonBuilder().create();

    // Logger interface
    private final Logger logger = (Logger) LoggerFactory.getLogger(CustomProducerVariables.class);

    // Constructor
    public CustomProducerVariables() throws IOException {
        // Delay between each scan in distant folder
        String checkDelay = System.getenv("sftp-check-delay");
        if(checkDelay != null && checkDelay != "") {
            try {
                logger.info("SFTP Check delay found in settings. Trying to set it...");

                SftpCheckDelay = Integer.parseInt(checkDelay);

                logger.info("SFTP Check delay set!");
            }

            catch(Exception ex) {
                logger.error("Unable to parse SFTP Check delay parameter. Default applied (10000).");
            }
        }

        // SFTP Server port
        String port = System.getenv("sftp-port");
        if(port != null && port != "") {
            try {
                logger.info("SFTP port found in settings. Trying to set it...");
                SftpPort = Integer.parseInt(port);
            }
            catch(Exception e) {
                logger.error("Error while parsing given SFTP Port parameter! Default applied (22).");
            }
        }
    }

    // Checking if every mandatory variables are present in env variables
    // Returns: true if every variable is present, false is at least one is missing
    public boolean CheckVariables() {
        boolean status = false;

        if (TopicName == null || TopicName == "") {
            logger.error("Missing topic name config!");
        }

        else if (BootstrapServers == null || BootstrapServers == "") {
            logger.error("Missing bootstrap servers config!");
        }

        else if (ProducerUsername == null || ProducerUsername == "") {
            logger.error("Missing producer username config!");
        }

        else if (ProducerPassword == null || ProducerPassword == "") {
            logger.error("Missing producer password config!");
        }

        else if (NumberOfPartitions == null || NumberOfPartitions == "") {
            logger.error("Missing number of partitions config!");
        }

        else if (ReplicationFactor == null || ReplicationFactor == "") {
            logger.error("Missing replication factor config!");
        }

        else if (SecurityProtocol == null || SecurityProtocol == "") {
            logger.error("Missing security protocol config!");
        }

        else if (SaslMechanism == null || SaslMechanism == "") {
            logger.error("Missing SASL Mechanism config!");
        }

        else if (SslCaLocation == null || SslCaLocation == "") {
            logger.error("Missing ssl ca location config!");
        }

        else if (SftpUsername == null || SftpUsername == "") {
            logger.error("Missing SFTP Username config!");
        }

        else if (SftpPrivateKey == null || SftpPrivateKey == "") {
            logger.error("Missing SFTP Private Key!");
        }

        else if (SftpHost == null || SftpHost == "") {
            logger.error("Missing SFTP Host config!");
        }

        else if (SftpPath == null || SftpPath == "") {
            logger.error("Missing SFTP Path config!");
        }

        else if (Separator == null || Separator == "") {
            logger.error("Missing CSV column separator config!");
        }

        else {
            status = true;
        }

        // Checking for message backoff config
        String messageBackoff = System.getenv("message-backoff");
        if(messageBackoff != null && messageBackoff != "") {
            try {
                logger.info("Message Backoff config found in settings, trying to apply it...");
                MessageBackOff = Long.parseLong(messageBackoff);
            }
            catch(Exception e) {
                logger.error("Invalid message backoff parameter(" + e.toString() + ")! Applying default setting (100)...");
            }
        }

        // Checking if additional columns are given
        String additionalColumnsSrc = System.getenv("additional-columns");
        if(additionalColumnsSrc != null && additionalColumnsSrc != "") {
            try {
                logger.info("Additional columns config found in settings, trying to apply it...");

                // Serializing data as an array of AdditionalColumn objects
                AdditionalColumns = _gson.fromJson(additionalColumnsSrc, AdditionalColumn[].class);
            }
            catch(Exception e) {
                logger.error("Invalid additional columns parameter(" + e.toString() + ")! Skipping it...");
            }
        }

        // Checking if separator is a metacharacter, in this case, casting it as a char instead of regex expression
        boolean contains = false;
        String[] charArray = {"(", ")", "[", "]", "{", "}", "\\", "^", "\"", "$", "|", "?", "*", "+", ".", "<", ">", "-", "=", "!"};
        for (String s : charArray) {
            if (Separator.equals(s)) {
                contains = true;
                break;
            }
        }
        if (contains == true) {
            logger.info("CSV file seperator is a metacharacter, correcting config...");
            Separator = "\\" + Separator;
        }

        return status;
    }
}
