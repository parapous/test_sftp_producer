/*
 * Filename : AdditionalColumn.java
 * Description : Use when deserializing data from settings files.
 */

package com.projet;

public class AdditionalColumn {
    // Name of the additional column
    String name;

    // Value of the additional column
    String value;
}
