/*
 * Filename : SftpProducer.java
 * Description : Custom SFTP Producer, for the project
 */

package com.projet;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.KafkaAdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.config.TopicConfig;
import org.apache.kafka.common.errors.TopicExistsException;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.lang.*;
import java.io.*;
import java.util.*;
import java.util.HashMap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import com.gozen.CustomProducerVariables;
import com.gozen.SftpConnect;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SftpProducer {
    // Main method
    public static void main(String[] args) throws Exception {
        System.out.println("==================================================");
        System.out.println("============== Custom SFTP producer ==============");
        System.out.println("==================================================");
        System.out.println("Creating SFTP Producer object...");
        SftpProducer producer = new SftpProducer();
        System.out.println("Starting SFTP Producer...");
        producer.start();
    }

    // Contains every variables (from env...)
    private CustomProducerVariables _customVar;

    // Used to establish and use SFTP connection to server
    private SftpConnect _sftpConnect;

    // Kafka environment prefix
    private String KAFKA_ENV_PREFIX = "KAFKA_";

    // Kafka properties object
    private Properties _properties;

    // File processing timestamp
    private Date _fileTimestamp;

    // Default kafka properties
    private Map<String, String> _defaultProps;

    // Used to Serialize/Deserialize JSON objects
    private Gson _gson = new GsonBuilder().create();

    // Number of errors that happend during file processing
    private int _errorCount = 0;

    // Used for shutdown hook
    boolean _status = true;

    // Logger class
    private final Logger _logger = (Logger) LoggerFactory.getLogger(SftpProducer.class);

    // Kafka producer object
    private Producer<String, String> _producer;

    // SFTP producer constructor
    public SftpProducer() throws ExecutionException, InterruptedException {
        _customVar = new CustomProducerVariables();
        _defaultProps = Map.of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, _customVar.BootstrapServers,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, _customVar.KeySerializerClass,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, _customVar.ValueSerializerClass);

        _properties = buildProperties(_defaultProps, System.getenv(), KAFKA_ENV_PREFIX);

        final Integer numberOfPartitions =  Integer.valueOf(System.getenv().getOrDefault("NUMBER_OF_PARTITIONS", _customVar.NumberOfPartitions));
        final Short replicationFactor =  Short.valueOf(System.getenv().getOrDefault("REPLICATION_FACTOR", _customVar.ReplicationFactor));
    }

    // Start method
    private void start() {
        _logger.info("Checking environment variables...");

        // Checking environment variables
        if(_customVar.CheckVariables()) {
            try {
                _logger.debug("Creating SFTP Connect object...");
                _sftpConnect = new SftpConnect(_customVar.SftpHost, _customVar.SftpUsername, _customVar.SftpPrivateKey, _customVar.SftpPort);

                _logger.debug("Creating producer object...");

                try {
                    _producer = new KafkaProducer(_properties);

                    _logger.debug("Initializing shutdown hook...");
                    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                        _logger.info("Shutdown hook catched!");
                        try {
                            while( !_status ) {
                                _logger.debug("Waiting for graceful shutdown...");
                                TimeUnit.MILLISECONDS.sleep(_customVar.SftpCheckDelay / 2 );
                            }
                            _logger.info("Closing producer...");
                            _producer.close();
                        } catch (Exception e) {
                            _logger.error("Exception catched while having shutdown hook: " + e.toString());
                            e.printStackTrace();
                        }
                        _logger.info("Application has exited");
                    }));

                    while(true) {
                        try {
                            if(_sftpConnect.Connect()) {
                                _logger.info("Scanning for CSV files...");
                                List<String> files = _sftpConnect.GetFilesFromPath(_customVar.SftpPath);

                                if(files.size() > 0) {
                                    _logger.info("At least one file has been found! Processing it...");
                                    processFile(files.get(0));
                                }

                                else {
                                    _logger.info("No files found in folder.");
                                }

                                if(_sftpConnect.Disconnect()) {
                                    _logger.info("Disconnected!");
                                }

                                else {
                                    _logger.error("Unable to disconnect!");
                                }
                            }

                            else {
                                _logger.error("Unable to connect to SFTP Server.");
                            }

                            _logger.info("Waiting for next scan...");
                            TimeUnit.MILLISECONDS.sleep(_customVar.SftpCheckDelay);
                        }
                        catch(Exception e) {
                            _logger.error("Exception while scanning for new files: " + e.toString());
                            if(_sftpConnect.Disconnect()) {
                                _logger.info("Disconnected!");
                            }

                            else {
                                _logger.error("Unable to disconnect.");
                            }
                        }
                    }
                }

                catch(Exception ex) {
                    _logger.error("Exception while creating Kafka Producer object: " + ex.toString());
                }
            }
            catch(Exception e) {
                _logger.error("Exception catched: " + e.toString());
            }
        }

        else {
            _logger.error("Unable to start custom producer: missing environment variables!");
        }

        _logger.info("Ending SFTP Producer...");
        _producer.close();
    }

    // Method that processes distant file
    private boolean processFile(String fileName) {
        _status = false;

        try {
            Date fileDate = new Date();
            long fileUnixTime = fileDate.getTime() / 1000L;
            String[] splitedString = fileName.split(".csv", 2);
            String newFileName = splitedString[0] + "-" + Long.toString(fileUnixTime) + ".processing";

            _logger.debug("Renaming file...");

            if(_sftpConnect.RenameFile(_customVar.SftpPath + "/" + fileName, _customVar.SftpPath + "/" + newFileName)) {
                String id;
                long lineCount = 0;
                _errorCount = 0;

                try {
                    BufferedReader br = _sftpConnect.GetReaderFromFile(_customVar.SftpPath + "/" + newFileName, _customVar.FileEncoding);

                    String line;
                    String[] schema = null;

                    while((line = br.readLine()) != null && _errorCount == 0) {
                        id = UUID.randomUUID().toString();
                        _fileTimestamp = new Date();
                        _logger.info("Writing line with key " + id + " to topic" + _customVar.TopicName);

                        if(_customVar.FirstRowAsHeader.equals("true") && lineCount == 0) {
                            _logger.debug("First row has header parameter detected. Scanning it...");
                            _logger.debug(line);
                            schema = line.split(_customVar.Separator);
                            _logger.debug("Schema defined, " + schema.length + " columns found.");
                            lineCount++;
                        }

                        else {
                            boolean status2 = false;

                            if(schema != null) {
                                status2 = sendMessage(line, id, _producer, schema, lineCount);
                            }

                            else {
                                status2 = sendMessage(line, id, _producer, null, lineCount);
                            }

                            if(status2) {
                                _logger.debug("Message sent!");
                                lineCount++;
                            }

                            else {
                                _logger.error("Unable to send message (line " + lineCount + ").");
                                _errorCount++;
                            }
                        }
                    }

                    _logger.info("Number of lines proceded: " + lineCount);
                }

                catch(Exception ex) {
                    _logger.error("Error while reading file content at line " + lineCount + ": " + ex.toString());
                    _errorCount++;
                }

                _producer.flush();

                _sftpConnect.CloseInputStream();
                if (_errorCount == 0) {
                    _logger.info("Deleting file...");
                    if (_sftpConnect.DeleteFile(_customVar.SftpPath + "/" + newFileName)) {
                        _logger.info("File deleted!");
                    } else {
                        _logger.error("File delete failed! You must go and delete it manually!");
                    }

                    _status = true;
                }
                else {
                    _logger.error("There was " + _errorCount + " errors, renaming it...");
                    Date errorDate = new Date();
                    long unixTime = errorDate.getTime() / 1000L;
                    String newFileName2 = splitedString[0] + "-" + Long.toString(unixTime) + ".error";

                    if(_sftpConnect.RenameFile(_customVar.SftpPath + "/" + newFileName, _customVar.SftpPath + "/" + newFileName2)) {
                        _logger.warn("File " + newFileName + " renamed successfully to " + newFileName2 + "!");
                    }

                    else {
                        _logger.error("Unable to rename file!");
                    }
                }
            }

            else {
                _logger.error("File rename failed! Re-looping...");
            }
        }

        catch(Exception e) {
            _logger.error("Exception while processing file: " + e.toString());
            _errorCount++;
        }

        return _status;
    }

    // Method that build properties object from multiple sources
    private Properties buildProperties(Map<String, String> baseProps, Map<String, String> envProps, String prefix) {
        Map<String, String> systemProperties = envProps.entrySet()
                .stream()
                .filter(e -> e.getKey().startsWith(prefix))
                .collect(Collectors.toMap(
                        e -> e.getKey()
                                .replace(prefix, "")
                                .toLowerCase()
                                .replace("_", ".")
                        , e -> e.getValue())
                );

        Properties props = new Properties();
        props.putAll(baseProps);
        props.putAll(systemProperties);

        if(_customVar.SaslMechanism != null && _customVar.SaslMechanism != "") {
            _logger.info("SASL Mechanism config detected, applying it...");
            props.put("sasl.mechanism", _customVar.SaslMechanism);
            props.put("sasl.jaas.config", "org.apache.kafka.common.security.plain.PlainLoginModule required username='" + _customVar.ProducerUsername + "' password='" + _customVar.ProducerPassword + "';");
        }

        props.put("security.protocol", _customVar.SecurityProtocol);
        props.put("ssl.ca.location", _customVar.SslCaLocation);
        return props;
    }

    // Callback method when a message is sent
    private void sendCallback(ProducerRecord<String, String> record, RecordMetadata recordMetadata, Exception e,long lineCount) {
        if (e == null) {
            _logger.info("Record successfully sent with offset: " + recordMetadata.offset());
        } else {
            _logger.error("Record sending failed on line " +lineCount+ "! sending key: " + record.key() + " " + e.toString());
            _errorCount++;
        }
    }

    // Method that sends a message to kafka
    private boolean sendMessage(String message, String key, Producer<String, String> producer, String[] schema,long lineCount) {
        boolean status = false;

        _logger.debug("Sending data to topic " + _customVar.TopicName + "...");
        try {
            if(schema != null) {
                String[] fields = message.split(_customVar.Separator);

                if(schema.length < fields.length) {
                    _logger.error("There is more fields than columns in schema!");
                    status = false;
                    _errorCount++;
                }

                else {
                    HashMap<String, String> messageMap = new HashMap<String, String>();

                    for(int i = 0; i < schema.length; i++) {
                        try {
                            messageMap.put(schema[i], fields[i]);
                        }
                        catch(Exception e) {
                            messageMap.put(schema[i], "");
                        }
                    }

                    messageMap.put("UUID", key);
                    long unixTime = _fileTimestamp.getTime() / 1000L;
                    messageMap.put("TIMESTAMP", Long.toString(unixTime));

                    if(_customVar.AdditionalColumns != null) {
                        _logger.debug("Additional columns found, applying it to message...");
                        try {
                            for(int i = 0; i < _customVar.AdditionalColumns.length; i++) {
                                messageMap.put(_customVar.AdditionalColumns[i].name, _customVar.AdditionalColumns[i].value);
                            }
                        }
                        catch(Exception e) {
                            _logger.error("Unable to apply additional columns to message: " + e.toString());
                            _errorCount++;
                        }
                    }

                    ProducerRecord<String, String> record = new ProducerRecord<>(_customVar.TopicName, key, _gson.toJson(messageMap));

                    producer.send(record,(recordMetadata, exception) -> sendCallback(record, recordMetadata, exception,lineCount));

                    TimeUnit.MILLISECONDS.sleep(_customVar.MessageBackOff);

                    status = true;
                }
            }

            else {
                ProducerRecord<String, String> record = new ProducerRecord<>(_customVar.TopicName, key, message);

                producer.send(record,(recordMetadata, exception) -> sendCallback(record, recordMetadata, exception, lineCount));

                TimeUnit.MILLISECONDS.sleep(_customVar.MessageBackOff);

                status = true;
            }
        }

        catch(Exception e) {
            _logger.error("Error catched while sending data to topic "+ lineCount + " "+ _customVar.TopicName + ": " + e.toString());
            _errorCount++;
        }

        return status;
    }
}
