/*
 * Filename : SftpConnect.java
 * Description : Used to connect to the SFTP Server.
 */

package com.projet;

import com.jcraft.jsch.*;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.ChannelSftp.*;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSchException;
import java.util.*;
import java.io.*;
import java.nio.charset.Charset;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.any23.encoding.TikaEncodingDetector;

public class SftpConnect {

    // Contains environment Variables
    private CustomProducerVariables customVar;

    // Host name/IP
    private String _host;

    // Username
    private String _username;

    // Password
    private String _privateKey;

    // Server port
    private int _port;

    // Jsch Objects, used to connect to the server and access files
    private JSch _jsch;
    private Session _session = null;
    private Channel _channel = null;
    private ChannelSftp _channelSftp;

    // Streams used to read file data
    private InputStream _inStream = null;
    private BufferedReader _br;

    // Logger class
    private final Logger _logger = (Logger) LoggerFactory.getLogger(SftpConnect.class);

    // Constructor
    // Host: host URL/IP
    // Username: Username
    // PrivateKey: private SSH Key
    // Port : Server port
    public SftpConnect(String host, String username, String privateKey, int port) {
        _host = host;
        _username = username;
        _privateKey = privateKey;
        _port = port;
    }
    //Setting session to SFTP Server
    public Session set_session(Session session, Channel channel) {

        try {
            session.connect();
            _logger.debug("Session is connected! Try to connect to SFTP channel...");
            channel = session.openChannel("sftp");
            channel.connect();
            _logger.debug("SFTP channel connected!");

        }catch(JSchException jSchException) {
            _logger.error("Unable to open Session : " + jSchException.toString());
        } finally {
            //while session status is false keep trying to connect
            if(!session.isConnected() || !channel.isConnected()) {
                _logger.debug("Retry Connection to SFTP Server in : " + + customVar.retryDelay + " seconds" );
                session = null;
                channel = null;
                try {
                    TimeUnit.SECONDS.sleep(customVar.retryDelay);
                } catch (InterruptedException e) {
                    _logger.error("InterruptedException Exception catched : " + e.toString());
                }
                set_session(session,channel);
            }
        }

        return session;
    }

    // Connect to SFTP server, and initializes sessions
    // Returns: true if connection is established successfully, false if something has append
    public boolean Connect() {
        _logger.debug("Connecting to SFTP server...");

        boolean status = false;
        int connectionRetry = 0;
        _privateKey = customVar.SftpPrivateKey;
        try {
            _jsch = new JSch();
            //Adding an SSH private key authentication
            _jsch.addIdentity(_privateKey);
            _logger.info("Successfully set identity using SSH Key");
            _session = _jsch.getSession(_username, _host, _port);
            //_session.setPassword(_password);
            // Disables host key verification
            //_session.setConfig("StrictHostKeyChecking", "no");
            _session = set_session(_session,_channel);
            status = true;

        }

        catch(JSchException e) {
            _logger.error("Error while connecting to SFTP server: " + e.toString());
        }

        return status;
    }

    // Close connection to SFTP Server
    // Returns: true if it has disconnected successfully, false if something has append
    public boolean Disconnect() {
        boolean status = false;
        _logger.debug("Disconnecting from SFTP Server...");

        try {
            _channelSftp.disconnect();
            _channel.disconnect();
            _logger.debug("Disconnected channels.");
        }

        catch(Exception e) {
            _logger.error("Exception catched while closing channels: " + e.toString());
        }

        try {
            _session.disconnect();
            _logger.debug("Disconnected session!");
            status = true;
        }
        catch(Exception e) {
            _logger.error("Unable to disconnect from SFTP Server: " + e.toString());
        }

        return status;
    }

    // Get files list from given path on remote server
    // Returns: List of strings (filename) if everything goes right
    // Empty list if something has append
    public List<String> GetFilesFromPath(String path) {
        List<String> allFiles = new ArrayList<>();

        try {
            _logger.debug("Getting CSV files list from path: " + path + "...");
            _channelSftp = (ChannelSftp)_channel;
            _channelSftp.cd(path);
            Vector<LsEntry> filelist = _channelSftp.ls(path);

            for(LsEntry entry : filelist){
                String filename = entry.getFilename();

                if(filename.contains(".csv")) {
                    allFiles.add(filename);
                }
            }

            _logger.debug("Found " + allFiles.size() + " csv files in path " + path);
        }

        catch(Exception e) {
            _logger.error("Exception while getting files from server: " + e.toString());
        }

        return allFiles;
    }

    // Rename file on distant server
    // Returns: true if success, false if something happend
    public boolean RenameFile(String oldFilePath, String newFilePath) {
        boolean status = false;

        try {
            _logger.debug("Renaming file " + oldFilePath + "...");
            _channelSftp.rename(oldFilePath, newFilePath);
            _logger.debug("Renamed file " + oldFilePath + " to " + newFilePath + "!");
            status = true;
        }

        catch(Exception e) {
            _logger.error("Unable to rename file: " + e.toString());
        }

        return status;
    }

    // Get BufferedReader from given file in order to read it
    // Returns: BufferedReader of file if success, null if something happend
    public BufferedReader GetReaderFromFile(String inputFilePath, String fileEncoding) {
        try {
            _logger.debug("Getting file " + inputFilePath + "...");
            _inStream = _channelSftp.get(inputFilePath);

            if(fileEncoding == null || fileEncoding.equals("")) {
                _logger.debug("Trying to autodetect file encoding...");
                Charset detectedCharset = Charset.forName(new TikaEncodingDetector().guessEncoding(_inStream));
                if(detectedCharset != null) {
                    _logger.debug("Detected charset: " + detectedCharset.name());
                    _logger.debug("Getting reader from file " + inputFilePath + " with encoding " + detectedCharset.name() + "...");
                    _inStream = _channelSftp.get(inputFilePath);
                    _br = new BufferedReader(new InputStreamReader(_inStream, detectedCharset.name()));
                }

                else {
                    _logger.error("Unable to detect file encoding.");
                    _br = null;
                }
            }

            else {
                _logger.debug("Getting reader from file " + inputFilePath + " with encoding " + fileEncoding + "...");
                _inStream = _channelSftp.get(inputFilePath);
                _br = new BufferedReader(new InputStreamReader(_inStream, fileEncoding));
            }

            return _br;
        }

        catch(Exception e) {
            _logger.error("Unable to get BufferedReader from file: " + e.toString());
            return null;
        }
    }

    // Closes input streams
    // Returns: true if success, false if something happend
    public boolean CloseInputStream() {
        boolean status = false;

        try {
            _logger.debug("Closing stream...");
            _inStream.close();
            return true;
        }

        catch(Exception e) {
            _logger.error("Unable to close input stream: " + e.toString());
        }

        return status;
    }

    // Delete file on remote server
    // Returns: true if success, false if something happend
    public boolean DeleteFile(String filePath) {
        boolean status = false;

        try {
            _logger.debug("Deleting file " + filePath + "...");
            _channelSftp.rm(filePath);
            status = true;
        }

        catch(Exception e) {
            _logger.error("Unable to remove file: " + e.toString());
        }

        return status;
    }
}
