# SFTP KAFKA Producer

Ce repository Git contient le Producer custom développé en Java dans le cadre du mini projet kafka producer.

## Comportement

Le producer ce connecte périodiquement à un serveur SFTP, et regarde les fichiers présents dans un dossier distant donné. Si un fichier CSV y est présent, le producer exécute la suite d'instructions suivante :

1.  Le fichier est renommé comme ce suit : "nomdufichier-UNIXTIMESTAMP.processing", afin d'éviter qu'une autre instance traite le même fichier en paralèle.
2.  En fonction des paramètres, le programme va récupérer ou non le schema via la première ligne du fichier
*  Dans le cas où les paramètres sont tels que la première ligne n'est pas le schema, le producer va simplement envoyer le contenu du fichier ligne par ligne dans Kafka.
3. Le fichier va lire ligne après ligne le fichier, et va éffectuer le traitement suivant
* Chaque valeur est mappée sur sa colonne correspondante (dans l'ordre)
* Des colonnes additionelles au schema peuvent être ajoutés avec leur valeur, en fonction des paramètres
* Un champ UUID aléatoire est assigné par ligne
* Un champ TIMESTAMP est ajouté au moment du traitement (au format UNIX)
4. Une fois le message constitué, celui-ci est envoyé dans le topic Kafka au format JSON (en string), avec comme clé l'UUID
5. Si aucune erreur n'as eu lieu durant le traitement du fichier, celui-ci est supprimé du dossier distant
6. Si une erreur ou plus à/ont eu lieu, le fichier est renommé au format suivant : "nomdufichier-UNIXTIMESTAMP.error"

## Configurations

### Configurations du connecteur

Voici la liste des configurations disponibles, ainsi que leurs différentes valeurs. Ceux-ci sont à configurer en variable d'environement du Pod, sous le format suivant :

`paramètre=valeur`

| Paramètre | Obligatoire ? | Valeurs |
| ------ | ------ | ------ |
| number-partitions | Oui | Nombre de partitions du topic (exemple: 4) |
| replication-factor | Oui | Replication factor du topic (exemple: 4)  |
| sasl-mechanism | Oui | Mécanisme d'authentification SASL utilisé pour la connexion à Kafka, mettre `PLAIN` dans le cas de GOZEN. |
| security-protocol | Oui | Protocole de sécurité utilisé pour la connexion à Kafka, mettre `SASL_SSL` dans le cas de GOZEN. |
| ssl-ca-location | Oui | Nom du fichier de certificat, pour l'authentification. Celui-ci est à placer dans le dossier ressources. Dans le cas de GOZEN, mettre `carioca.truststore.jks` |
| message-backoff | Non | Nombre de messages maximum à commit d'un seul coup. Valeur par défaut: 100 |
| sftp-check-delay | Non | Interval en millisecondes entre chaque scan du dossier distant (pour la détection de nouveaux fichiers). ATTENTION: prendre en compte le temps d'upload des fichiers, afin de ne pas lire des fichiers corrompus. Valeur par défaut : 10000 |
| bootstrap-servers | Oui | Adresses des Bootstrap Servers. Dans le cas de plusieurs serveurs, les séparer par une virgule (exemple: IP1,IP2) |
| topic | Oui | Nom du topic |
| producer-username | Oui | Nom d'utilisateur du producer dans kafka |
| producer-password | Oui | Mot de passe du producer dans kafka. ATTENTION: ce paramètre est à définir dans le Vault, et à configurer dans le déploiement. |
| sftp-port | Non | Port du serveur SFTP. Valeur par défaut : 22 |
| sftp-host | Oui | Adresse IP du serveur SFTP |
| sftp-username | Oui | Nom d'utilisateur sur le serveur SFTP |
| sftp-password | Oui | Mot de passe sur le serveur SFTP. ATTENTION: ce paramètre est à définir dans le Vault, et à configurer dans le déploiement. |
| sftp-path | Oui | Chemin vers le dossier d'input distant (exemple: /usr/gozen/data/i4i/test/test-dev/in) |
| file-encoding | Oui | Format d'encodage du fichier en entrée. Si vous ne renseignez pas de paramètre, celui sera détecté automatiquement, mais cela rajoute un énorme temps de traitement. Exemple de valeurs : [Documentation](https://docs.oracle.com/javase/8/docs/technotes/guides/intl/encoding.doc.html) (utiliser les valeurs Basic Encoding Set, colonne Canonical Name) |
| first-row-as-header | Oui | Indique si la première ligne du fichier CSV est le schéma (true ou false) |
| csv-separator | Oui | Caractère de séparation des colonnes dans le fichier CSV |
| additional-columns | Non | Colonnes + valeurs à rajouter dans chaque message. Doit être constitué au format suivant: `[{"name": "NomColonne", "value": "Valeur"}, {"name": "NomColonne2", "value": "Valeur2"}]` |

### Configurations des logs

Les logs par défauts sont réglés de manière à n'afficher que les logs qui ont un niveau supérieur ou égal à INFO. Si vous voulez le maximum de logs, vous pouvez régler le niveau de log dans le fichier `log4j2.xml` situé dans le dossier `ressources`.

Vous n'avez qu'a remplacer par objet le niveau de logs (DEBUG, INFO, WARN, ERROR).

## Format des messages

Les messages sont formattés de la façon suivante une fois envoyés dans Kafka :

`{"colonne1": "valeur1", "colonne2": "valeur2"}`

## Temps de traitement

Les tests ont étés réalisés sur le cluster Mutu. Ces performances peuvent donc être améliorées une fois sur l'environement final.

### Import dump provenant de IAM

Lors de l'import du fichier provenant d'IAM, contenant 8829 lignes, pour un poids total de 1,20 Mo, le producer à mis environ 1 minute 30s à importer les messages dans Kafka.

## Mesures de performances

Voici les mesures éffectuées via Grafana lors de l'import du fichier d'IAM (8829 lignes, 1.20 Mo) au bout de la 3ème injestion.

### Utilisation CPU

![](img/CPU%20Usage%20IAM.png)

### Utilisation RAM

![](img/Memory%20Usage%20IAM.png)

### Utilisation réseau

![](img/Network%20IO%20IAM.png)
